let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let username = localStorage.getItem("username") || null;

const loginScreen = document.getElementById("loginScreen");
const todoApp = document.getElementById("todoApp");
const usernameInput = document.getElementById("usernameInput");
const loginBtn = document.getElementById("loginBtn");
const usernameDisplay = document.getElementById("usernameDisplay");
const logoutBtn = document.getElementById("logoutBtn");
const toggleTheme = document.getElementById("toggleTheme");

const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const priorityInput = document.getElementById("priorityInput");
const dateInput = document.getElementById("dateInput");
const taskList = document.getElementById("taskList");

const filterPriority = document.getElementById("filterPriority");
const filterStatus = document.getElementById("filterStatus");

function saveData() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
  const priorityFilter = filterPriority.value;
  const statusFilter = filterStatus.value;

  taskList.innerHTML = "";

  tasks.forEach((task, index) => {
    if ((priorityFilter !== "todas" && task.priority !== priorityFilter) ||
        (statusFilter === "hechas" && !task.done) ||
        (statusFilter === "pendientes" && task.done)) return;

    const li = document.createElement("li");
    if (task.done) li.classList.add("done");

    li.innerHTML = `
      <div class="task-info">
        <strong>${task.text}</strong>
        <small>Prioridad: ${task.priority} | Fecha: ${task.date || "—"}</small>
      </div>
      <div class="task-actions">
        <button onclick="toggleDone(${index})">✔</button>
        <button onclick="deleteTask(${index})">✖</button>
      </div>
    `;
    taskList.appendChild(li);
  });
}

function toggleDone(index) {
  tasks[index].done = !tasks[index].done;
  saveData();
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  saveData();
  renderTasks();
}

taskForm.addEventListener("submit", e => {
  e.preventDefault();
  const text = taskInput.value.trim();
  if (!text) return;

  const newTask = {
    text,
    priority: priorityInput.value,
    date: dateInput.value,
    done: false
  };

  tasks.push(newTask);
  taskInput.value = "";
  dateInput.value = "";
  saveData();
  renderTasks();
});

filterPriority.addEventListener("change", renderTasks);
filterStatus.addEventListener("change", renderTasks);

loginBtn.addEventListener("click", () => {
  const user = usernameInput.value.trim();
  if (user) {
    username = user;
    localStorage.setItem("username", user);
    showApp();
  }
});

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("username");
  username = null;
  showLogin();
});

toggleTheme.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
});

function showApp() {
  usernameDisplay.textContent = username;
  loginScreen.classList.add("hidden");
  todoApp.classList.remove("hidden");
  renderTasks();
}

function showLogin() {
  loginScreen.classList.remove("hidden");
  todoApp.classList.add("hidden");
}

if (username) {
  showApp();
} else {
  showLogin();
}

if (localStorage.getItem("theme") === "dark") {
  document.body.classList.add("dark");
}
